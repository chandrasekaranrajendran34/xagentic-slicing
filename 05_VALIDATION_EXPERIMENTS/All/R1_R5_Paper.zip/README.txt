R1-R5 consolidated conference-paper drafting package
R1_R5_Paper.docx: methodology, contributions, publication tables, figures, manuscript prose, reviewer matrix.
Table*.csv: publication tables. Figure*.png: figures.
All numbers transcribed from frozen evidence summaries; no experiment rerun.
